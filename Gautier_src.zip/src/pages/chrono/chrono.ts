import { Component } from '@angular/core';
import { NavController} from 'ionic-angular';
import {TimerComponent} from '../timer/timer';



@Component ({
    selector : "page-chrono",
    templateUrl : "chrono.html"
})

export class ChronoPage {
    constructor() {} 

  

}
