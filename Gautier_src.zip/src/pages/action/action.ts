import { Component } from '@angular/core';
import { NavController,Platform } from 'ionic-angular';
import { TimerService } from '../../app/services/timer.service';
//import { AlertController } from 'ionic-angular';




@Component({
    selector : 'page-action',
    templateUrl : 'action.html'
})

export class ActionPage {
joueur:any;
action:any;
zone:any;
temps:any;
savedDisplayTime: string;



    
   constructor(public navCtrl: NavController,private timerService: TimerService/*private alertCtrl: AlertController*/) {
    this.getDefaults();
    
  };

  getDefaults(){
    if(localStorage.getItem('joueur') != null){
      this.joueur = localStorage.getItem('joueur');
    } else {
      this.joueur = 1;
    }
    if(localStorage.getItem('action') != null){
      this.action = localStorage.getItem('action');
    } else {
      this.action = 1;
    }
    if(localStorage.getItem('zone') != null){
      this.zone = localStorage.getItem('zone');
    } else {
      this.zone = 4;
    }
  }

getDisplayTime() {
    return this.timerService.getDisplayTime();
  }
   pickTimer() {
    this.savedDisplayTime = this.getDisplayTime();
  }

  getSavedDisplayTime() {
    return this.savedDisplayTime;
  }



   setDefaults(){
    localStorage.setItem('joueur', this.joueur);
    localStorage.setItem('action', this.action);
    localStorage.setItem('zone', this.zone);
    localStorage.setItem('temps', this.temps=this.getDisplayTime());

   // this.navCtrl.push(RedditsPage);
  }

 /*showConfirm() {
    let confirm = this.alertCtrl.create({
      title: 'Etes-vous sûr?',
      message: 'Vérifier et confirmer votre choix',
      buttons: [
        {
          text: 'Modifier',
          handler: () => {
          }
        },
        {
          text: 'Accepter',
          handler: () => {
           this.setDefaults();
          }
        }
      ]
    });
    confirm.present();
  }*/


}

