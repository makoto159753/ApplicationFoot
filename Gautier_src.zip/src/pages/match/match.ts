import { Component } from '@angular/core';
import { NavController,Platform } from 'ionic-angular';
import {ChronoPage } from '../chrono/chrono';




@Component({
  selector: 'page-match',
  templateUrl: 'match.html'
})
export class MatchPage {
  type:string;
  duree:any;
  meteo:any;
  equipe:any;
  equipe2:any

  constructor(public navCtrl: NavController) {
    this.getDefaults();
  };

  getDefaults(){
    if(localStorage.getItem('type') != null){
      this.type = localStorage.getItem('type');
    } else {
      this.type = 'amical';
    }
    if(localStorage.getItem('duree') != null){
      this.duree = localStorage.getItem('duree');
    } else {
      this.duree = 60;
    }
    if(localStorage.getItem('meteo') != null){
      this.meteo = localStorage.getItem('meteo');
    } else {
      this.meteo = 'soleil';
    }
    if(localStorage.getItem('equipe') != null){
      this.equipe = localStorage.getItem('equipe');
    } else {
      this.equipe = 'toucan';
    }
    if(localStorage.getItem('equipe2') != null){
      this.equipe2 = localStorage.getItem('equipe2');
    } else {
      this.equipe2 = 1;
    }
  }
  setDate (e:Event) {
    var a=new Date(e.toString());
    console.log(e);
    console.log(e.toString());
    console.log(a);
  } 
  

  setDefaults(){
    localStorage.setItem('type', this.type);
    localStorage.setItem('duree', this.duree);
    localStorage.setItem('meteo', this.meteo);
    localStorage.setItem('equipe', this.equipe);
    localStorage.setItem('equipe2', this.equipe2);
   // var retrievedObject = localStorage.getItem('type');
    //var parsedObject = JSON.parse(retrievedObject);
    localStorage.getItem('type');

  }

  
}

