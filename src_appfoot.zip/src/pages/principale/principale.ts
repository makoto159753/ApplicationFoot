import { Component } from '@angular/core';
import { NavController,Platform } from 'ionic-angular';

@Component ({
    selector : 'page-principale',
    templateUrl : 'principale.html'
})

export class PrincipalePage {

    constructor() {

    }
}